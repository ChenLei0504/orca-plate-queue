// Cloud print pipeline (start_print / start_local_print_with_record).
//
// Shared cloud bookkeeping for both ABI entry points, then a delivery
// fork that intentionally diverges from current stock hybrid behaviour
// (stock uploads the main .3mf to S3 even on "LAN+record" and the
// printer re-downloads it — see ../research/11.02-cloud-upload.md §11.2.2):
//
//   [A]  POST   /v1/iot-service/api/user/project
//   [B]  PUT    <presigned>                                       config 3mf
//   [C]  PUT    /v1/iot-service/api/user/notification
//   [D]  GET    /v1/iot-service/api/user/notification?action=upload&ticket=..
//
//   use_lan_channel=true  (_with_record):
//   [E]  FTPS STOR main .3mf first (Upload; WR_UPLOAD_FTP on fail)
//   [A–D] then project + config S3 (Record) + notify
//   [F]  PATCH  /v1/iot-service/api/user/project/<pid>            url=ftp://...
//   [G]  POST   /v1/user-service/my/task                          mode=lan_file
//
//   use_lan_channel=false (start_print):
//   Create, then [A–D], then:
//   [E]  GET    /v1/iot-service/api/user/upload?models=...
//   [F]  PUT    <presigned>                                       main 3mf (Upload)
//   [G]  PATCH  /v1/iot-service/api/user/project/<pid>            url=S3
//   [H]  POST   /v1/user-service/my/task                          mode=cloud_file
//
// Config upload [B]/[D] is required for Print History thumbnails.
// Print start is cloud /my/task dispatch — the plugin does not publish
// MQTT project_file (would double-fire). On LAN failure the plugin
// returns < 0 so Studio can fall back to start_print.

#include "obn/agent.hpp"

#include "obn/bambu_networking.hpp"
#include "obn/signing.hpp"
#include "obn/cloud_auth.hpp"
#include "obn/config.hpp"
#include "obn/http_client.hpp"
#include "obn/json_lite.hpp"
#include "obn/log.hpp"
#include "obn/print_job.hpp"
#include "obn/print_params_ftp_prefs.hpp"

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <memory>
#include <sstream>
#include <string>
#include <system_error>
#include <thread>
#include <vector>

#include <openssl/evp.h>

namespace obn {

namespace {

// Compact JSON array escape helper reused from the LAN path.
std::string json_escape(const std::string& in)
{
    return obn::json::escape(in);
}

// Redacts a presigned URL for logging: keeps scheme://host/path and the
// query-parameter *names* (so we can tell a SigV4 PUT-presign apart from a
// GET-presign, spot an expiry, etc.) but drops every query *value* — the
// AWS signature and any embedded token must never hit the log. A trailing
// "?<k1>=…&<k2>=…" summary is appended so the shape stays diagnosable.
std::string redact_url(const std::string& url)
{
    const auto q = url.find('?');
    if (q == std::string::npos) return url;
    std::string out = url.substr(0, q);
    out += " ?[";
    std::size_t i = q + 1;
    bool first = true;
    while (i < url.size()) {
        std::size_t amp = url.find('&', i);
        std::size_t end = (amp == std::string::npos) ? url.size() : amp;
        std::size_t eq  = url.find('=', i);
        std::string key = (eq != std::string::npos && eq < end)
                              ? url.substr(i, eq - i)
                              : url.substr(i, end - i);
        if (!first) out += ',';
        out += key;
        first = false;
        if (amp == std::string::npos) break;
        i = amp + 1;
    }
    out += ']';
    return out;
}

// Reads the whole file into memory. The print-ready 3mf is typically
// a few MB up to ~100 MB; config 3mf is always <200KB. We keep a
// single buffer in memory for both because libcurl's PUT path wants
// the data in one shot (CURLOPT_POSTFIELDS). If we ever need to
// stream multi-GB uploads, the right fix is a read-callback variant
// of obn::http::Request, not chunking here.
std::string slurp_file(const std::string& path, std::string* err)
{
    std::ifstream ifs(path, std::ios::binary);
    if (!ifs) {
        if (err) *err = "open failed";
        return {};
    }
    std::ostringstream oss;
    oss << ifs.rdbuf();
    if (!ifs && !ifs.eof()) {
        if (err) *err = "read failed";
        return {};
    }
    return oss.str();
}

// Stock plugin hashes the print-ready .3mf itself and puts the digest
// in PATCH profile_print_3mf[].md5 (uppercase hex). Studio never fills
// PrintParams.ftp_file_md5 — the field exists only on the ABI struct.
// Cloud accepts an all-zero placeholder (OBN used to send one) but
// stock never does; see stock_hybrid.mitm 2026-07-19.
std::string md5_file_hex_upper(const std::string& path)
{
    std::ifstream ifs(path, std::ios::binary);
    if (!ifs) return {};

    std::unique_ptr<EVP_MD_CTX, void(*)(EVP_MD_CTX*)> ctx(
        EVP_MD_CTX_new(),
        [](EVP_MD_CTX* c) { if (c) EVP_MD_CTX_free(c); });
    if (!ctx || EVP_DigestInit_ex(ctx.get(), EVP_md5(), nullptr) != 1)
        return {};

    char buf[64 * 1024];
    while (ifs) {
        ifs.read(buf, sizeof(buf));
        const auto n = ifs.gcount();
        if (n > 0 &&
            EVP_DigestUpdate(ctx.get(), buf, static_cast<std::size_t>(n)) != 1)
            return {};
    }
    if (!ifs.eof()) return {};

    unsigned char digest[EVP_MAX_MD_SIZE] = {};
    unsigned len = 0;
    if (EVP_DigestFinal_ex(ctx.get(), digest, &len) != 1 || len == 0)
        return {};

    static const char kHex[] = "0123456789ABCDEF";
    std::string hex(len * 2, '\0');
    for (unsigned i = 0; i < len; ++i) {
        hex[2 * i    ] = kHex[(digest[i] >> 4) & 0xF];
        hex[2 * i + 1] = kHex[ digest[i]       & 0xF];
    }
    return hex;
}

// AMS mapping helpers. Studio hands us the mapping as a JSON array
// string in params.ams_mapping ("[0,-1,-1,-1]") and richer info in
// params.ams_mapping2 / ams_mapping_info. We pass them through
// verbatim when they look like valid JSON; otherwise fall back to
// a conservative empty mapping.

std::string trim(std::string s)
{
    while (!s.empty() && (s.front() == ' ' || s.front() == '\t' ||
                          s.front() == '\r' || s.front() == '\n'))
        s.erase(s.begin());
    while (!s.empty() && (s.back() == ' ' || s.back() == '\t' ||
                          s.back() == '\r' || s.back() == '\n'))
        s.pop_back();
    return s;
}

std::string json_or_default(const std::string& raw, const char* fallback)
{
    std::string s = trim(raw);
    if (s.empty()) return fallback;
    // Cheap validator: accept only strings that look like a JSON
    // array/object (first char). json::parse would be stricter but
    // also much slower; the mapping strings come from Studio's own
    // serializer, so a sniff is enough.
    if (s.front() == '[' || s.front() == '{') return s;
    return fallback;
}

// True when the caller actually handed us a mapping. Stock treats the
// mapping keys as optional and omits them outright for an empty string
// instead of substituting a default, so this gates them below. `[]` is
// lumped in with "absent" since an empty array carries no mapping either
// (this half is an inference — every stock body we captured without a
// mapping had the field as an empty string).
bool has_json_payload(const std::string& raw)
{
    const std::string s = trim(raw);
    if (s.empty() || s == "[]") return false;
    return s.front() == '[' || s.front() == '{';
}

// Build a single amsMapping2 element as the server expects it:
// `{"amsId":N,"slotId":M}` (camelCase). The convention observed in
// the MITM dump is:
//   -1   -> amsId=255, slotId=0 (unset / "external spool" sentinel)
//   >=0  -> amsId=i/4, slotId=i%4 (linear index over AMS slot 0..3)
// The external-spool sentinel is `{amsId:255,slotId:0}`, NOT
// `{...,slotId:255}`: the endpoint 400s on the wrong shape
// (cross-validated in #48), and stock emits exactly this pair for a -1
// entry. A job with no AMS at all sends no amsMapping2 key whatsoever —
// see the gate in build_task_body.
std::string ams_slot_pair(int ams_id, int slot_id)
{
    return "{\"amsId\":" + std::to_string(ams_id) +
           ",\"slotId\":" + std::to_string(slot_id) + "}";
}

// Produce the amsMapping2 JSON array for /my/task.
//
// Studio *does* hand us a p.ams_mapping2 string, but it's serialized
// with snake_case keys (`ams_id`, `slot_id`) as used by the printer's
// internal MQTT schema. The cloud `/my/task` endpoint only accepts
// camelCase (`amsId`, `slotId`) and 400s with
// `field "amsMapping2[0].amsId" is not set` otherwise.
//
// We therefore parse Studio's JSON ourselves and re-serialize into the
// camelCase shape. If that fails or Studio gave us nothing usable, we
// fall back to deriving the mapping from the flat p.ams_mapping array
// (`[0,-1,2,-1]`).
std::string ams_mapping2_for_cloud(const BBL::PrintParams& p)
{
    auto derived_from_flat = [&]() {
        auto root = obn::json::parse(p.ams_mapping);
        if (!root || !root->is_array()) return std::string("[]");
        std::string out = "[";
        bool first = true;
        for (const auto& v : root->as_array()) {
            if (!v.is_number()) continue;
            int idx = static_cast<int>(v.as_number());
            int ams_id, slot_id;
            if (idx < 0) { ams_id = 255; slot_id = 0; }
            else         { ams_id = idx / 4; slot_id = idx % 4; }
            if (!first) out.push_back(',');
            first = false;
            out += ams_slot_pair(ams_id, slot_id);
        }
        out.push_back(']');
        return out;
    };

    std::string raw = trim(p.ams_mapping2);
    if (raw.empty() || raw == "[]") return derived_from_flat();

    auto root = obn::json::parse(raw);
    if (!root || !root->is_array()) return derived_from_flat();

    std::string out = "[";
    bool first = true;
    for (const auto& item : root->as_array()) {
        // Accept either schema. Prefer camelCase if present (future-
        // proof against Studio catching up), otherwise snake_case.
        auto ams_v  = item.find("amsId");
        if (!ams_v.is_number())  ams_v  = item.find("ams_id");
        auto slot_v = item.find("slotId");
        if (!slot_v.is_number()) slot_v = item.find("slot_id");
        int ams_id  = ams_v.is_number()  ? static_cast<int>(ams_v.as_number())  : 255;
        // Missing slot defaults to 0 to match the external-spool sentinel
        // {amsId:255,slotId:0} (see ams_slot_pair note; #48).
        int slot_id = slot_v.is_number() ? static_cast<int>(slot_v.as_number()) : 0;
        if (!first) out.push_back(',');
        first = false;
        out += ams_slot_pair(ams_id, slot_id);
    }
    out.push_back(']');
    return out;
}

std::string to_bool(bool v) { return v ? "true" : "false"; }

#if ABI_VERSION >= 0x020802
// Whole-string int64 parse; anything that isn't one (empty, alphabetic,
// trailing junk, out of range) collapses to 0 so the caller can drop the
// field, which is how stock treats an unusable queue_plate_id.
long long parse_int64_or_zero(const std::string& s)
{
    if (s.empty()) return 0;
    errno = 0;
    char* end = nullptr;
    const long long v = std::strtoll(s.c_str(), &end, 10);
    if (errno == ERANGE || end != s.c_str() + s.size()) return 0;
    return v;
}
#endif

// ---------------------------------------------------------------
// HTTP plumbing
// ---------------------------------------------------------------

using obn::cloud::bbl_headers;

bool status_ok(long code) { return code >= 200 && code < 300; }

// Reports a transport or HTTP error through Studio's update_fn and
// stashes the server message where our log scraper can see it.
int fail_stage(BBL::OnUpdateStatusFn update_fn, int code, const std::string& what,
               const obn::http::Response& resp)
{
    std::string detail = what;
    if (!resp.error.empty()) detail += ": " + resp.error;
    else if (resp.status_code != 0)
        detail += ": HTTP " + std::to_string(resp.status_code);
    OBN_ERROR("cloud_print: %s (body=%.2000s)", detail.c_str(), resp.body.c_str());
    if (update_fn) {
        try {
            update_fn(BBL::PrintingStageERROR, code, detail);
        } catch (const std::exception& e) {
            OBN_WARN("cloud_print: update_fn threw: %s", e.what());
        } catch (...) {
            OBN_WARN("cloud_print: update_fn threw unknown exception");
        }
    }
    return code;
}

// ---------------------------------------------------------------
// Per-step HTTP calls
// ---------------------------------------------------------------

struct ProjectInfo {
    std::string project_id;
    std::string model_id;
    std::string profile_id;
    std::string upload_url;     // presigned S3 PUT for the config 3mf (step B)
    std::string upload_ticket;  // fed back into the notification endpoint
};

int create_project(const std::string& api, const std::string& token,
                   const std::string& user_id,
                   const std::string& name, ProjectInfo* out,
                   BBL::OnUpdateStatusFn update_fn)
{
    obn::http::Request req;
    req.method  = obn::http::Method::POST;
    req.url     = api + "/v1/iot-service/api/user/project";
    req.headers = bbl_headers(token, user_id);
    req.body    = std::string("{\"name\":") + json_escape(name) + "}";
    req.timeout_s = 30;

    auto resp = obn::http::perform(req);
    if (!resp.error.empty() || !status_ok(resp.status_code))
        return fail_stage(update_fn, BAMBU_NETWORK_ERR_PRINT_WR_REQUEST_PROJECT_ID_FAILED,
                          "create_project", resp);

    std::string perr;
    auto root = obn::json::parse(resp.body, &perr);
    if (!root) {
        OBN_ERROR("cloud_print: create_project bad JSON: %s (body=%s)",
                  perr.c_str(), resp.body.c_str());
        if (update_fn) update_fn(BBL::PrintingStageERROR,
                                 BAMBU_NETWORK_ERR_PRINT_WR_REQUEST_PROJECT_ID_FAILED,
                                 "bad JSON");
        return BAMBU_NETWORK_ERR_PRINT_WR_REQUEST_PROJECT_ID_FAILED;
    }
    out->project_id    = root->find("project_id").as_string();
    out->model_id      = root->find("model_id").as_string();
    out->profile_id    = root->find("profile_id").as_string();
    out->upload_url    = root->find("upload_url").as_string();
    out->upload_ticket = root->find("upload_ticket").as_string();

    if (out->project_id.empty() || out->upload_url.empty()) {
        OBN_ERROR("cloud_print: create_project missing fields: body=%s",
                  resp.body.c_str());
        if (update_fn) update_fn(BBL::PrintingStageERROR,
                                 BAMBU_NETWORK_ERR_PRINT_WR_REQUEST_PROJECT_ID_FAILED,
                                 "missing fields");
        return BAMBU_NETWORK_ERR_PRINT_WR_REQUEST_PROJECT_ID_FAILED;
    }
    OBN_INFO("cloud_print: project pid=%s mid=%s prof=%s",
             out->project_id.c_str(), out->model_id.c_str(), out->profile_id.c_str());
    OBN_DEBUG("cloud_print: config upload_url=%s", redact_url(out->upload_url).c_str());
    return 0;
}

// PUT bytes to a presigned S3 URL. Amazon's signature covers only the
// method + resource + expiry + AWS key; query-string presigned URLs
// are forgiving of extra headers, which is why the original plugin
// blithely sends its X-BBL-* set on them too. We mimic that.
int s3_put(const std::string& url, const std::string& body,
           BBL::OnUpdateStatusFn update_fn,
           BBL::WasCancelledFn   cancel_fn,
           int                   progress_stage,
           int                   err_code)
{
    obn::http::Request req;
    req.method  = obn::http::Method::PUT;
    req.url     = url;
    // The Bambu cloud presigner returns an S3 signature-V2 query-auth URL
    // (`?AWSAccessKeyId=…&Expires=…&Signature=…`), confirmed on-wire
    // against genuine POST /user/project traffic (us-west-2, 2026-07).
    // NOT SigV4 — there is no X-Amz-Algorithm / X-Amz-Signature. The V2
    // StringToSign covers Content-Type, and the presigner signs with an
    // empty one, so we MUST send the PUT without a Content-Type or the
    // signature will not match. Two catches:
    //   * libcurl, when doing a PUT via CUSTOMREQUEST+POSTFIELDS, silently
    //     injects `Content-Type: application/x-www-form-urlencoded`. The
    //     idiomatic way to tell libcurl to drop a header is to append
    //     the header name followed by a colon and NO value.
    //   * libcurl also auto-adds `Expect: 100-continue` for bodies > 1 KiB;
    //     Studio's original plugin omits it, so we do the same.
    req.no_default_content_type = true; // don't add our own application/json
    req.no_default_accept       = true; // don't add our own Accept: application/json
    req.headers["Content-Type"] = "";   // REMOVE libcurl's auto Content-Type
    req.headers["Expect"]       = "";   // REMOVE libcurl's auto Expect: 100-continue
    req.is_upload               = true; // Use CURLOPT_UPLOAD with 1MB chunk streaming
    req.body      = body;
    // Dynamic timeout: floor of 1800s (30m), plus scale for large files (~10 KB/s budget).
    req.timeout_s = std::max<int>(1800, static_cast<int>(body.size() / 10240));
    // Abort if transfer stalls below 1 KB/s for 60 consecutive seconds.
    req.low_speed_limit  = 1024;
    req.low_speed_time_s = 60;

    const auto total = static_cast<std::uint64_t>(body.size());
    if (update_fn)
        update_fn(progress_stage, 0, print_job::format_upload_info(0, total));

    int last_pct = -1;
    req.progress_cb = [&](std::uint64_t /*dltotal*/, std::uint64_t /*dlnow*/,
                          std::uint64_t ultotal, std::uint64_t ulnow) -> bool {
        if (cancel_fn && cancel_fn())
            return false;
        if (update_fn && ultotal > 0) {
            int pct = static_cast<int>((ulnow * 100) / ultotal);
            if (pct != last_pct) {
                last_pct = pct;
                try {
                    update_fn(progress_stage, pct, print_job::format_upload_info(ulnow, ultotal));
                } catch (...) {}
            }
        }
        return true;
    };

    auto resp = obn::http::perform(req);
    if (!resp.error.empty() || !status_ok(resp.status_code)) {
        if (cancel_fn && cancel_fn()) {
            OBN_WARN("cloud_print: s3 PUT canceled by user");
            return BAMBU_NETWORK_ERR_CANCELED;
        }
        return fail_stage(update_fn, err_code, "s3 PUT", resp);
    }

    OBN_DEBUG("cloud_print: s3 PUT ok http=%ld bytes=%zu url=%s",
              resp.status_code, body.size(), redact_url(url).c_str());

    if (update_fn)
        update_fn(progress_stage, 100, print_job::format_upload_info(total, total));
    return 0;
}

int notify_upload(const std::string& api, const std::string& token,
                  const std::string& user_id,
                  const std::string& ticket, const std::string& origin_name,
                  BBL::OnUpdateStatusFn update_fn)
{
    obn::http::Request req;
    req.method  = obn::http::Method::PUT;
    req.url     = api + "/v1/iot-service/api/user/notification";
    req.headers = bbl_headers(token, user_id);
    std::ostringstream os;
    os << "{\"upload\":{\"origin_file_name\":" << json_escape(origin_name)
       << ",\"ticket\":" << json_escape(ticket) << "}}";
    req.body    = os.str();
    req.timeout_s = 30;
    auto resp = obn::http::perform(req);
    if (!resp.error.empty() || !status_ok(resp.status_code))
        return fail_stage(update_fn, BAMBU_NETWORK_ERR_PRINT_WR_PUT_NOTIFICATION_FAILED,
                          "notify_upload", resp);
    return 0;
}

// Polls /notification?action=upload until the async upload settles.
// HTTP is always 200; the body is {"message":"running"|"success", ...}.
// Keep polling while message=="running"; "success" ends the wait. Any
// other message is a hard failure.
int poll_upload(const std::string& api, const std::string& token,
                const std::string& user_id,
                const std::string& ticket,
                BBL::OnUpdateStatusFn update_fn,
                BBL::WasCancelledFn cancel_fn)
{
    std::map<std::string, std::string> hdrs = bbl_headers(token, user_id);
    hdrs.erase("Content-Type"); // GET
    const std::string url = api
        + "/v1/iot-service/api/user/notification?action=upload&ticket="
        + obn::http::url_encode(ticket);

    for (int attempt = 0; attempt < 20; ++attempt) {
        if (cancel_fn && cancel_fn()) return BAMBU_NETWORK_ERR_CANCELED;
        auto resp = obn::http::get_json(url, hdrs);
        if (!resp.error.empty() || !status_ok(resp.status_code)) {
            OBN_DEBUG("cloud_print: poll_upload attempt=%d status=%ld err=%s",
                      attempt, resp.status_code, resp.error.c_str());
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            continue;
        }

        auto root = obn::json::parse(resp.body);
        const std::string msg = root ? root->find("message").as_string()
                                     : std::string{};
        if (msg == "running") {
            OBN_DEBUG("cloud_print: poll_upload running attempt=%d", attempt);
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            continue;
        }
        if (msg == "success") {
            OBN_DEBUG("cloud_print: poll_upload OK attempt=%d", attempt);
            return 0;
        }
        return fail_stage(update_fn, BAMBU_NETWORK_ERR_PRINT_WR_GET_NOTIFICATION_FAILED,
                          "poll_upload", resp);
    }
    if (update_fn) update_fn(BBL::PrintingStageERROR,
                             BAMBU_NETWORK_ERR_PRINT_WR_GET_NOTIFICATION_TIMEOUT,
                             "upload poll timeout");
    return BAMBU_NETWORK_ERR_PRINT_WR_GET_NOTIFICATION_TIMEOUT;
}

// PATCH /project/<pid> with the profile_print_3mf descriptor that
// points at where the print-ready 3mf now lives. Studio issues this
// twice - once with a throw-away ftp:// placeholder before the real
// OSS upload, once more with the real URL afterwards. We copy that
// pattern because the server-side state machine seems to care about
// the first call being present.
int patch_project(const std::string& api, const std::string& token,
                  const std::string& user_id,
                  const std::string& project_id,
                  const std::string& profile_id,
                  const std::string& md5, int plate_idx,
                  const std::string& url,
                  BBL::OnUpdateStatusFn update_fn)
{
    obn::http::Request req;
    req.method    = obn::http::Method::PATCH;
    req.url       = api + "/v1/iot-service/api/user/project/" + project_id;
    req.headers   = bbl_headers(token, user_id);
    req.timeout_s = 30;
    std::ostringstream os;
    os << "{\"profile_id\":" << json_escape(profile_id)
       << ",\"profile_print_3mf\":[{"
       << "\"md5\":" << json_escape(md5)
       << ",\"plate_idx\":" << (plate_idx <= 0 ? 1 : plate_idx)
       << ",\"url\":" << json_escape(url)
       << "}]}";
    req.body = os.str();

    auto resp = obn::http::perform(req);
    if (!resp.error.empty() || !status_ok(resp.status_code))
        return fail_stage(update_fn, BAMBU_NETWORK_ERR_PRINT_WR_PATCH_PROJECT_FAILED,
                          "patch_project", resp);
    return 0;
}

int get_upload_url(const std::string& api, const std::string& token,
                   const std::string& user_id,
                   const std::string& model_slot,
                   std::string* out_url,
                   BBL::OnUpdateStatusFn update_fn)
{
    std::map<std::string, std::string> hdrs = bbl_headers(token, user_id);
    hdrs.erase("Content-Type"); // GET
    std::string url = api + "/v1/iot-service/api/user/upload?models="
                    + obn::http::url_encode(model_slot);
    auto resp = obn::http::get_json(url, hdrs);
    if (!resp.error.empty() || !status_ok(resp.status_code))
        return fail_stage(update_fn, BAMBU_NETWORK_ERR_PRINT_WR_GET_USER_UPLOAD_FAILED,
                          "get_upload_url", resp);
    // Raw body holds only presigned URLs + object keys (no account secrets);
    // kept at DEBUG for diagnosing endpoint shape changes.
    OBN_DEBUG("cloud_print: get_upload_url raw body=%s", resp.body.c_str());
    auto root = obn::json::parse(resp.body);
    if (!root) return fail_stage(update_fn, BAMBU_NETWORK_ERR_PRINT_WR_GET_USER_UPLOAD_FAILED,
                                 "bad get_upload_url JSON", resp);
    auto arr_v = root->find("urls");
    const auto& arr = arr_v.as_array();
    if (arr.empty())
        return fail_stage(update_fn, BAMBU_NETWORK_ERR_PRINT_WR_GET_USER_UPLOAD_FAILED,
                          "get_upload_url empty", resp);
    auto url_v = arr.front().find("url");
    *out_url = url_v.as_string();
    if (out_url->empty())
        return fail_stage(update_fn, BAMBU_NETWORK_ERR_PRINT_WR_GET_USER_UPLOAD_FAILED,
                          "get_upload_url missing url", resp);
    OBN_DEBUG("cloud_print: get_upload_url -> %s", redact_url(*out_url).c_str());
    return 0;
}

// The body of POST /my/task is the single biggest surface we have to
// mimic from Studio. The MITM baseline is ~30 fields; most of them
// map 1:1 to PrintParams. Anything we can't sensibly provide (custom
// filament mappings from MakerWorld, nozzle_info for multi-nozzle
// printers) we default to an empty array, which the server accepts.
std::string build_task_body(const BBL::PrintParams& p,
                            const std::string& project_id,
                            const std::string& model_id,
                            const std::string& profile_id,
                            bool use_lan_channel)
{
    (void)project_id;
    std::ostringstream os;
    os << "{";
    os << "\"amsDetailMapping\":"
       << json_or_default(p.ams_mapping_info, "[]");
    // Both mapping keys are optional. Stock 02.08.02.54 omits them for an
    // empty string, and `task_use_ams` on its own does not bring them back
    // (probed with useAms=true + empty mappings -> neither key), so keying
    // them off useAms or defaulting amsMapping to [-1] over-reports on a
    // no-AMS job. Conversely they *are* emitted with useAms=false when the
    // strings are filled: each key is gated by its own field.
    // amsMapping goes out verbatim; amsMapping2 is re-keyed to camelCase
    // (see ams_mapping2_for_cloud) — stock does the same conversion, which
    // is why Studio's snake_case input never reaches the wire.
    if (has_json_payload(p.ams_mapping))
        os << ",\"amsMapping\":" << trim(p.ams_mapping);
    if (has_json_payload(p.ams_mapping2) || has_json_payload(p.ams_mapping))
        os << ",\"amsMapping2\":" << ams_mapping2_for_cloud(p);
    os << ",\"autoBedLeveling\":"     << p.auto_bed_leveling;
    os << ",\"bedLeveling\":"         << to_bool(p.task_bed_leveling);
    os << ",\"bedType\":" << json_escape(p.task_bed_type.empty()
                                         ? std::string{"auto"} : p.task_bed_type);

    // Decimal bitmask sent as a *string*, identical to the one the plugin
    // puts in the LAN project_file (see print_job.cpp). Two bits are known,
    // both probed one at a time against stock 02.08.02.54:
    //   bit 0 (value 1) = task_ext_change_assist
    //   bit 2 (value 4) = task_timelapse_use_internal
    // Bit 1 (value 2) never appeared for any PrintParams field we can set
    // (try_emmc_print included), so it is not reachable through this ABI.
    // task_record_timelapse is deliberately absent here: it rides in the
    // separate `timelapse` key and leaves cfg at 0.
    int cfg_bits = 0;
    if (p.task_ext_change_assist) cfg_bits |= 1;
    #if ABI_VERSION >= 0x020503
        if (p.task_timelapse_use_internal &&
            !obn::config::current().force_timelapse_external)
            cfg_bits |= 4;
    #endif
    os << ",\"cfg\":\"" << cfg_bits << "\"";
    // cover and filamentSettingIds stay empty: stock still sent "" and []
    // with every PrintParams string filled with sentinels, so neither is fed
    // from this ABI — they come from Studio state the plugin reads elsewhere.
    os << ",\"cover\":\"\"";
    // Dropped when zero, matching Studio's default — it only fills
    // stl_design_id for MakerWorld STL-sourced models.
    if (p.stl_design_id != 0)
        os << ",\"designId\":" << p.stl_design_id;
    os << ",\"deviceId\":"     << json_escape(p.dev_id);
    os << ",\"extrudeCaliFlag\":"         << p.auto_flow_cali;
    #if ABI_VERSION >= 0x020400
        // -1 is Studio's "not set" default and stock drops the key for it.
        if (p.extruder_cali_manual_mode != -1)
            os << ",\"extrudeCaliManualMode\":" << p.extruder_cali_manual_mode;
    #endif
    os << ",\"filamentSettingIds\":[]";
    os << ",\"flowCali\":"            << to_bool(p.task_flow_cali);
    os << ",\"layerInspect\":"        << to_bool(p.task_layer_inspect);
    os << ",\"mode\":"
       << (use_lan_channel ? std::string{"\"lan_file\""}
                           : std::string{"\"cloud_file\""});
    os << ",\"modelId\":"     << json_escape(model_id);
    os << ",\"nozzleInfos\":" << json_or_default(p.nozzles_info, "[]");
    if (has_json_payload(p.nozzle_mapping))
        os << ",\"nozzleMapping\":" << trim(p.nozzle_mapping);
    os << ",\"nozzleOffsetCali\":"    << p.auto_offset_cali;
    os << ",\"oriModelId\":"  << json_escape(p.origin_model_id);
    os << ",\"oriProfileId\":" << p.origin_profile_id;
#if ABI_VERSION >= 0x020802
    // queue_plate_id crosses the ABI as a string but goes on the wire as a
    // JSON *number*, and the key is dropped when it doesn't parse or parses
    // to zero — stock 02.08.02.54 emitted plateId=9988776655 for the numeric
    // sentinel and no key at all for the alphabetic one. int64 because the
    // service's plate ids exceed 32 bits. See
    // ../research/08.08-print-abi.md §8.8.1.
    if (const long long plate_id = parse_int64_or_zero(p.queue_plate_id))
        os << ",\"plateId\":" << plate_id;
#endif
    os << ",\"plateIndex\":"  << (p.plate_index <= 0 ? 1 : p.plate_index);
    // profileId must be a number in the MITM baseline.
    os << ",\"profileId\":"   << (profile_id.empty() ? std::string{"0"} : profile_id);
    // Per-attempt counter in stock: the first POST of a create_task call is
    // always 20001 and each retry bumps it (20002/20003 seen on 400 and 403
    // responses), while a later, separate create_task starts over at 20001.
    // We never retry, so the first value is all we ever emit.
    os << ",\"sequence_id\":\"20001\"";
#if ABI_VERSION >= 0x020701
    // Opaque string forwarded verbatim, omitted when empty. Unlike
    // slicer_uid this one is cloud-only — it never appears in the LAN
    // project_file. See ../research/08.08-print-abi.md §8.8.1.
    if (!p.svc_context.empty())
        os << ",\"svcContext\":" << json_escape(p.svc_context);
#endif
    os << ",\"timelapse\":"   << to_bool(p.task_record_timelapse);
    os << ",\"title\":"       << json_escape(p.project_name.empty()
                                             ? p.task_name : p.project_name);
    os << ",\"useAms\":"      << to_bool(p.task_use_ams);
    os << ",\"vibrationCali\":" << to_bool(p.task_vibration_cali);
    os << "}";
    return os.str();
}

// Attach the obn.conf mytask_pop signing pair to the /my/task headers.
//
// The default (key absent or `auto`) decides by region: the CN cloud
// answers 403 to the bearer-only request that api.bambulab.com accepts
// for the same account and client name (H2D report 2026-10-08,
// obn(2).log: client_name=BambuStudio, still 403; research/10.05 lists
// /my/task as PoP-required on secured printers), so the pair is attached
// there and the long-standing behaviour is kept everywhere else.
// mytask_pop = 1 forces the pair on for any region, 0 forces it off
// (including CN). On, we attach x-bbl-app-certification-id +
// x-bbl-device-security-sign. add_pop_headers is best-effort and
// key-match guarded: no material or a key/cert mismatch means no headers
// rather than a blank pair that would 403 on its own. The cloud verifies
// x-bbl-device-security-sign by recovering a recent timestamp from the
// signature (current time in ms, raw PKCS#1 v1.5, not the body). The HTTP
// header uses `issuer:serial.lower()`, a DIFFERENT serialization from the
// MQTT envelope cert_id (`serial+issuer`); add_pop_headers emits the HTTP
// form, so the MQTT-form 403 does not apply here.
//
// Returns true when the pair was attached, false when omitted (effective
// flag off, or on with unusable signing material).
bool apply_mytask_pop(std::map<std::string, std::string>& hdrs,
                      const std::string& region)
{
    const auto& cfg = obn::config::current();
    const bool on = cfg.mytask_pop_set ? cfg.mytask_pop
                                       : obn::config::is_cn_region(region);
    if (!on) {
        OBN_DEBUG("cloud_print: mytask_pop off (region=%s); PoP headers omitted",
                  region.c_str());
        return false;
    }
    if (!obn::signing::add_pop_headers(hdrs)) {
        OBN_WARN("cloud_print: mytask_pop on but PoP headers were not attached "
                 "(slicer key/cert missing or mismatched; see obn.conf "
                 "slicer_key_pem/slicer_cert_pem)");
        return false;
    }
    OBN_DEBUG("cloud_print: mytask_pop on (region=%s) attached PoP cert_id='%s' "
              "sec_sign_len=%zu",
              region.c_str(),
              hdrs["x-bbl-app-certification-id"].c_str(),
              hdrs["x-bbl-device-security-sign"].size());
    return true;
}

// A 403 on the bearer-only request is the only signal worth a retry with
// more headers: H2D printers answer 403 on /my/task without the
// proof-of-possession pair on every cloud region (issue #6, user reports;
// mytask_pop=auto only attaches on CN), while any other status means the
// failure has another cause that extra headers will not fix.
bool should_retry_mytask_pop(int status_code, bool pop_attached)
{ return status_code == 403 && !pop_attached; }

int create_task(const std::string& api, const std::string& region,
                const std::string& token,
                const std::string& user_id,
                const std::string& body, std::string* out_task_id,
                BBL::OnUpdateStatusFn update_fn)
{
    // MakerWorld's /my/task endpoint is picky about amsMapping2 /
    // amsDetailMapping field shape; log the full body so we can diff
    // against the MITM dump when it 400s.
    OBN_DEBUG("cloud_print: create_task body=%s", body.c_str());
    obn::http::Request req;
    req.method  = obn::http::Method::POST;
    req.url     = api + "/v1/user-service/my/task";
    auto hdrs = bbl_headers(token, user_id);
    OBN_DEBUG("cloud_print: create_task hdr X-BBL-Client-Name=%s X-BBL-OS-Type=%s "
              "(config client_name=%s) uid=%s",
              hdrs["X-BBL-Client-Name"].c_str(), hdrs["X-BBL-OS-Type"].c_str(),
              obn::config::current().client_name.c_str(), user_id.c_str());
    // The cloud rejects a non-BambuStudio client name on this endpoint
    // with 403, so surface the config mistake before the response does.
    if (hdrs["X-BBL-Client-Name"] != "BambuStudio")
        OBN_WARN("cloud_print: create_task X-BBL-Client-Name=%s is not "
                 "BambuStudio; /my/task answers 403 for it (obn.conf "
                 "client_name, see research/06.06-cloud-rest.md)",
                 hdrs["X-BBL-Client-Name"].c_str());
    const bool pop_attached = apply_mytask_pop(hdrs, region);
    req.headers   = std::move(hdrs);
    req.body      = body;
    req.timeout_s = 60;

    auto resp = obn::http::perform(req);

    // The H2D (at least) 403s the bearer-only variant of this request on
    // every region, so when the pair was omitted and the cloud answers
    // 403, attach it and retry once. The retry is best-effort; if
    // the signing material is unusable the original 403 stands and
    // fail_stage below reports it unchanged.
    if (should_retry_mytask_pop(resp.status_code, pop_attached) &&
        obn::signing::add_pop_headers(req.headers)) {
        OBN_INFO("cloud_print: create_task got 403 without PoP headers; "
                 "retrying once with the proof-of-possession pair");
        resp = obn::http::perform(req);
    }

    // Hard-fail on any transport error or non-2xx: POST /my/task registers the
    // print with MakerWorld and, for cloud prints, is what actually authorizes
    // the printer to fetch the uploaded content. Swallowing its failure led to
    // silent breakage (the job would proceed with task_id=0 and then stall on
    // the printer with "failed to download"), so surface it instead.
    // The most common cause of a 403 here is X-BBL-Client-Name != "BambuStudio"
    // (see config::client_name) or an X-BBL-OS-Type / uploader-OS mismatch.
    // Note: this path is only reached for cloud prints (bambu_network_start_print)
    // and "local print with record" (start_local_print_with_record); block_cloud
    // stops run_cloud_print_job before we ever get here, and pure LAN printing
    // (start_local_print -> run_local_print_job) never calls /my/task.
    if (!resp.error.empty() || resp.status_code < 200 || resp.status_code >= 300)
        return fail_stage(update_fn, BAMBU_NETWORK_ERR_PRINT_WR_POST_TASK_FAILED,
                          "create_task", resp);

    auto root = obn::json::parse(resp.body);
    if (!root) {
        OBN_WARN("cloud_print: create_task bad JSON; continuing with task_id=0");
        *out_task_id = "0";
        return 0;
    }
    *out_task_id = root->find("id").as_string();
    if (out_task_id->empty()) {
        // Some builds return id as an integer; json_lite as_string()
        // returns empty for numeric values.
        const auto& rbody = resp.body;
        auto pos = rbody.find("\"id\"");
        if (pos != std::string::npos) {
            pos = rbody.find_first_of("0123456789", pos);
            if (pos != std::string::npos) {
                auto end = rbody.find_first_not_of("0123456789", pos);
                *out_task_id = rbody.substr(pos, end == std::string::npos
                                                 ? std::string::npos
                                                 : end - pos);
            }
        }
    }
    if (out_task_id->empty()) {
        OBN_WARN("cloud_print: create_task missing task_id; continuing with task_id=0");
        *out_task_id = "0";
    }
    OBN_INFO("cloud_print: task_id=%s", out_task_id->c_str());
    return 0;
}

} // namespace

#ifdef OBN_TESTING
// Thin wrappers that give anonymous-namespace functions external linkage
// so cloud_print_test can exercise them without extracting them.
namespace cloud_print {
std::string test_ams_mapping2(const BBL::PrintParams& p)
    { return ams_mapping2_for_cloud(p); }
std::string test_build_task_body(const BBL::PrintParams& p,
                                 const std::string& project_id,
                                 const std::string& model_id,
                                 const std::string& profile_id,
                                 bool use_lan_channel)
    { return build_task_body(p, project_id, model_id, profile_id, use_lan_channel); }
std::string test_md5_file_hex_upper(const std::string& path)
    { return md5_file_hex_upper(path); }
bool test_apply_mytask_pop(std::map<std::string, std::string>& hdrs,
                           const std::string& region)
    { return apply_mytask_pop(hdrs, region); }
bool test_should_retry_mytask_pop(int status_code, bool pop_attached)
    { return should_retry_mytask_pop(status_code, pop_attached); }
} // namespace cloud_print
#endif

int Agent::run_cloud_print_job(const BBL::PrintParams& p,
                               BBL::OnUpdateStatusFn   update_fn,
                               BBL::WasCancelledFn     cancel_fn,
                               bool                    use_lan_channel)
{
    OBN_INFO("cloud_print dev=%s ip=%s plate=%d file=%s config=%s project=%s chan=%s",
             p.dev_id.c_str(), p.dev_ip.c_str(), p.plate_index,
             p.filename.c_str(), p.config_filename.c_str(),
             p.project_name.c_str(),
             use_lan_channel ? "lan" : "cloud");

    // Studio's PrintJob::process picks the ABI entry point:
    //   start_local_print_with_record -> use_lan_channel=true
    //   start_print                   -> use_lan_channel=false
    // On LAN failure we return < 0 so Studio can fall back to start_print.

    if (p.filename.empty()) {
        if (update_fn) update_fn(BBL::PrintingStageERROR,
                                 BAMBU_NETWORK_ERR_FILE_NOT_EXIST,
                                 "empty filename");
        return BAMBU_NETWORK_ERR_FILE_NOT_EXIST;
    }

    // Hard stop: never push a print file through Bambu's cloud when the
    // user has opted out. Studio normally avoids this path because the
    // printer is never marked cloud-online under block_cloud, but a future
    // Studio update or unexpected dispatch must not be able to upload to
    // S3 behind the user's back. See issue #41.
    if (obn::config::current().block_cloud) {
        OBN_WARN("run_cloud_print_job: blocked by block_cloud");
        if (update_fn) update_fn(BBL::PrintingStageERROR,
                                 BAMBU_NETWORK_ERR_INVALID_HANDLE,
                                 "cloud print blocked by config");
        return BAMBU_NETWORK_ERR_INVALID_HANDLE;
    }

    auto session = user_session_snapshot();
    if (session.access_token.empty() || session.user_id.empty()) {
        if (update_fn) update_fn(BBL::PrintingStageERROR,
                                 BAMBU_NETWORK_ERR_INVALID_HANDLE,
                                 "not logged in");
        return BAMBU_NETWORK_ERR_INVALID_HANDLE;
    }
    const std::string api   = obn::cloud::api_host(cloud_region());
    const std::string token = session.access_token;
    const std::string uid   = session.user_id;

    // Stock start_print emits Create; start_local_print_with_record does
    // not (stock_hybrid / stock_block_lan Studio logs, 2026-07-19).
    if (!use_lan_channel && update_fn)
        update_fn(BBL::PrintingStageCreate, 0, "");
    if (cancel_fn && cancel_fn()) return BAMBU_NETWORK_ERR_CANCELED;

    std::string remote_name = print_job::pick_remote_name(p);
    // Stock ignores ftp_file_md5 (Studio leaves it empty) and hashes
    // the print-ready file. Uppercase hex, same as stock_hybrid.mitm.
    std::string md5 = md5_file_hex_upper(p.filename);
    if (md5.empty()) {
        OBN_ERROR("cloud_print: md5 %s failed", p.filename.c_str());
        if (update_fn) update_fn(BBL::PrintingStageERROR,
                                 BAMBU_NETWORK_ERR_PRINT_WR_CHECK_MD5_FAILED,
                                 "md5 failed");
        return BAMBU_NETWORK_ERR_PRINT_WR_CHECK_MD5_FAILED;
    }
    OBN_INFO("cloud_print: file md5=%s", md5.c_str());

    std::string project_url; // ftp://… or S3 https — registered via PATCH
    std::string stored_path;

    // Hybrid stock does FTPS of the main .3mf first (Upload), then the
    // cloud bookkeeping. A blocked LAN therefore fails with WR_UPLOAD_FTP
    // before Create — matching stock_block_lan.log.
    if (use_lan_channel) {
        if (p.dev_ip.empty() || p.password.empty()) {
            OBN_ERROR("cloud_print: lan channel requested but no dev_ip/access_code");
            if (update_fn) update_fn(BBL::PrintingStageERROR,
                                     BAMBU_NETWORK_ERR_CONNECTION_TO_PRINTER_FAILED,
                                     "no dev_ip/access_code for LAN print");
            return BAMBU_NETWORK_ERR_CONNECTION_TO_PRINTER_FAILED;
        }

        publish_peer_cert_pin(p.dev_ip, p.dev_id);

        std::string lan_remote_path =
            print_job::build_ftp_remote_path(p, remote_name);
        OBN_INFO("cloud_print: upload path=ftps :990 remote=%s ftp_folder='%s'",
                 lan_remote_path.c_str(), p.ftp_folder.c_str());

        print_params_set_use_ssl_for_ftp(p.use_ssl_for_ftp);

        std::uint64_t total = 0;
        std::string ca_file = bambu_ca_bundle_path();
        if (int rc = print_job::ftp_upload(p, lan_remote_path, ca_file,
                                           update_fn, cancel_fn,
                                           BAMBU_NETWORK_ERR_PRINT_WR_UPLOAD_FTP_FAILED,
                                           total, &stored_path);
            rc != 0) return rc;
        if (!stored_path.empty()) lan_remote_path = stored_path;
        project_url = print_job::build_ftp_url(lan_remote_path);
        OBN_INFO("cloud_print: lan-ftps uploaded %llu bytes to %s (url=%s)",
                 static_cast<unsigned long long>(total),
                 lan_remote_path.c_str(), project_url.c_str());
    }

    // Hybrid stock switches to Record as soon as FTPS finishes, covering
    // POST /user/project + the config S3 PUT. start_print stays on Upload.
    if (update_fn) {
        if (use_lan_channel)
            update_fn(BBL::PrintingStageRecord, 0, "");
        else
            update_fn(BBL::PrintingStageUpload, 0, "");
    }

    // -------------------------------------------------------------
    // [A] Create the cloud project and get the first presigned URL
    // -------------------------------------------------------------
    std::string project_name = p.project_name.empty() ? p.task_name : p.project_name;
    if (project_name.empty()) project_name = "untitled";
    ProjectInfo info{};
    if (int rc = create_project(api, token, uid, project_name, &info, update_fn);
        rc != 0) return rc;

    // -------------------------------------------------------------
    // [B] Upload the config 3mf (small). Required for Print History
    // thumbnails even when the main model is delivered over FTPS.
    // Hybrid stock reports this as Record; start_print as Upload.
    // -------------------------------------------------------------
    std::string config_path = p.config_filename;
    if (p.config_filename.empty()) {
        OBN_WARN("cloud_print: config_filename is empty, uploading the main file (%s) instead",
                 p.filename.c_str());
        config_path = p.filename;
    }
    std::string slurp_err;
    std::string config_bytes = slurp_file(config_path, &slurp_err);
    if (config_bytes.empty()) {
        OBN_ERROR("cloud_print: config read %s: %s",
                  config_path.c_str(), slurp_err.c_str());
        if (update_fn) update_fn(BBL::PrintingStageERROR,
                                 BAMBU_NETWORK_ERR_FILE_NOT_EXIST,
                                 "config_filename not readable");
        return BAMBU_NETWORK_ERR_FILE_NOT_EXIST;
    }
    const int config_stage = use_lan_channel ? BBL::PrintingStageRecord
                                             : BBL::PrintingStageUpload;
    OBN_INFO("cloud_print: uploading config %s to S3 (stage=%d)",
             config_path.c_str(), config_stage);
    if (int rc = s3_put(info.upload_url, config_bytes, update_fn, cancel_fn,
                        config_stage,
                        BAMBU_NETWORK_ERR_PRINT_WR_UPLOAD_3MF_CONFIG_TO_OSS_FAILED);
        rc != 0) return rc;

    // -------------------------------------------------------------
    // [C/D] Notify + poll.
    // -------------------------------------------------------------
    std::string origin_cfg = std::filesystem::path(config_path).filename().string();
    if (int rc = notify_upload(api, token, uid, info.upload_ticket,
                               origin_cfg, update_fn);
        rc != 0) return rc;
    if (int rc = poll_upload(api, token, uid, info.upload_ticket,
                             update_fn, cancel_fn);
        rc != 0) return rc;

    if (use_lan_channel) {
        if (int rc = patch_project(api, token, uid, info.project_id, info.profile_id,
                                   md5, p.plate_index, project_url, update_fn);
            rc != 0) return rc;
    } else {
        // ---------------------------------------------------------
        // Cloud delivery: main .3mf to S3 + PATCH S3 URL.
        // ---------------------------------------------------------
        std::string main_upload_url;
        std::string plate_tag =
            std::to_string(p.plate_index <= 0 ? 1 : p.plate_index);
        std::string model_slot =
            info.model_id + "_" + info.profile_id + "_" + plate_tag + ".3mf";
        if (int rc = get_upload_url(api, token, uid, model_slot,
                                    &main_upload_url, update_fn);
            rc != 0) return rc;

        std::string main_bytes = slurp_file(p.filename, &slurp_err);
        if (main_bytes.empty()) {
            OBN_ERROR("cloud_print: main read %s: %s",
                      p.filename.c_str(), slurp_err.c_str());
            if (update_fn) update_fn(BBL::PrintingStageERROR,
                                    BAMBU_NETWORK_ERR_FILE_NOT_EXIST,
                                    "filename not readable");
            return BAMBU_NETWORK_ERR_FILE_NOT_EXIST;
        }
        if (int rc = s3_put(main_upload_url, main_bytes, update_fn, cancel_fn,
                            BBL::PrintingStageUpload,
                            BAMBU_NETWORK_ERR_PRINT_WR_UPLOAD_3MF_TO_OSS_FAILED);
            rc != 0) return rc;

        project_url = main_upload_url;
        if (int rc = patch_project(api, token, uid, info.project_id, info.profile_id,
                                   md5, p.plate_index, project_url, update_fn);
            rc != 0) return rc;
    }

    // -------------------------------------------------------------
    // POST /my/task — cloud dispatches the print (no plugin MQTT).
    // -------------------------------------------------------------
    if (update_fn) update_fn(BBL::PrintingStageSending, 0, "");

    std::string task_body = build_task_body(p, info.project_id, info.model_id,
                                            info.profile_id, use_lan_channel);
    std::string task_id;
    if (int rc = create_task(api, cloud_region(), token, uid, task_body,
                             &task_id, update_fn);
        rc != 0) return rc;


    print_job::emit_finished_countdown(update_fn, cancel_fn);
    OBN_INFO("cloud_print dev=%s: queued (project=%s task=%s delivery=%s url=%s)",
             p.dev_id.c_str(), info.project_id.c_str(), task_id.c_str(),
             use_lan_channel ? "ftps" : "s3",
             use_lan_channel ? project_url.c_str()
                             : redact_url(project_url).c_str());
    return 0;
}

} // namespace obn
